# Design System Strategy: The Hyper-Lucid Gallery

## 1. Overview & Creative North Star
This design system is built upon the Creative North Star of **"The Hyper-Lucid Gallery."** While standard social platforms often feel like cluttered utility tools, this system treats the interface as a high-end editorial space where the UI recedes to let the content breathe. 

We move beyond the "standard clone" by utilizing **Organic Minimalism**. Instead of rigid grids separated by lines, we use intentional asymmetry in story placement, generous white space, and a sophisticated layering of surfaces. The objective is to make the user feel like they are flipping through a premium physical lookbook rather than scrolling through a database.

## 2. Colors & Surface Architecture
The palette is rooted in high-contrast neutrals, using the iconic gradient not as a layout tool, but as a "pulse" of energy for active states and notifications.

### The "No-Line" Rule
To maintain an editorial feel, **1px solid borders are strictly prohibited for sectioning.** Boundaries must be defined through tonal transitions. Use `surface-container-low` (#f1f1f1) sections against the `background` (#f6f6f6) to define content blocks.

### Surface Hierarchy & Nesting
Depth is achieved through a "Physical Stacking" model:
- **Base Layer:** `surface` (#f6f6f6) for the main application canvas.
- **Content Blocks:** Use `surface-container-low` (#f1f1f1) for feed backgrounds to subtly ground the posts.
- **Elevated Interactive Elements:** Use `surface-container-lowest` (#ffffff) for cards or search bars to create a "lifted" effect.
- **Glassmorphism:** For top navigation and the bottom tab bar, use `surface` at 80% opacity with a `backdrop-filter: blur(20px)`. This integrates the UI with the content scrolling beneath it.

### The Gradient Pulse
The "iconic gradient" is reserved for high-impact moments. Use a linear transition from `primary` (#b6004f) to `secondary` (#8037b1) for:
- Story rings (active state).
- Primary CTA buttons.
- New notification indicators.

## 3. Typography: Editorial Precision
The system utilizes **Inter** across the board, but creates hierarchy through dramatic scale shifts rather than font variety.

- **Display & Headlines:** Use `headline-lg` (2rem) for profile headers to give an authoritative, magazine-like feel. 
- **Body & Captions:** `body-md` (0.875rem) is the workhorse. Increase the line-height (1.5) to ensure readability and a "luxury" feel.
- **Labels:** `label-sm` (0.6875rem) should be used for timestamps and metadata, set in `on-surface-variant` (#5b5b5b) with a slight tracking increase (+2%) to maintain legibility at small sizes.

## 4. Elevation & Depth
Traditional drop shadows are too "software-heavy" for this system. We use **Tonal Layering** and **Ambient Shadows**.

- **The Layering Principle:** Place a `surface-container-lowest` (#ffffff) post card on a `surface-container-low` (#f1f1f1) feed background. This creates a natural, soft lift.
- **Ambient Shadows:** When a modal or floating action button is required, use a shadow with a blur radius of `32px` and an opacity of `6%`, using a tint of `on-surface` (#2f2f2f) rather than pure black.
- **The Ghost Border:** If a visual anchor is needed for accessibility (e.g., in a search input), use a "Ghost Border": `outline-variant` (#adadad) at **15% opacity**. Never use a 100% opaque border.

## 5. Component Logic

### Post Components
- **The Frame:** Posts have no borders. Use the `lg` (1rem) roundedness for the media container. 
- **Interaction Bar:** Icons (Heart, Comment, Share) must be spaced generously. Use `on-surface` (#2f2f2f) for the icons.
- **No-Divider Rule:** Forbid the use of divider lines between posts. Use a vertical spacing of `2.5rem` to separate feed items.

### Profile Avatars & Stories
- **Avatars:** Circular (`full` roundedness).
- **The Story Ring:** Use a `2px` gap between the avatar image and the gradient border. This "breathing room" prevents the gradient from bleeding into the photography.

### Buttons & Inputs
- **Primary Button:** High-gloss gradient (`primary` to `secondary`) with `on-primary` (#ffeff0) text. Use `full` roundedness for a modern, tactile feel.
- **Secondary Button:** `surface-container-high` (#e2e2e2) background with `on-surface` (#2f2f2f) text. No border.
- **Input Fields:** `surface-container-highest` (#dddddd) with `sm` (0.25rem) roundedness. The focus state should transition the background to `surface-container-lowest` (#ffffff) with a subtle "Ghost Border."

### Navigation (The Signature Bar)
The bottom navigation bar should be a floating "Island" rather than a docked block. Use `surface-container-lowest` (#ffffff) with a `xl` (1.5rem) roundedness and an Ambient Shadow. This makes the navigation feel like a physical tool sitting on top of the gallery.

## 6. Do's and Don'ts

### Do
- **Use White Space as a Border:** If two elements feel too close, increase padding rather than adding a line.
- **Vary Image Aspect Ratios:** Move away from the strict 1:1 square. Use 4:5 or 16:9 to enhance the editorial "magazine" feel.
- **Prioritize Content:** The UI should always be 15-20% less visually heavy than the photography it hosts.

### Don't
- **Don't use pure black (#000000) for text:** Use `on-background` (#2f2f2f) for a softer, premium reading experience.
- **Don't use hard-edged containers:** Every container should have at least the `DEFAULT` (0.5rem) roundedness to maintain the "Modern Social" aesthetic.
- **Don't use icons with varying stroke weights:** Ensure the standard icon set (home, search, add, heart, profile) uses a consistent 1.5px or 2px stroke.